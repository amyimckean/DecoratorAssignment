package Decorators;

import java.util.ArrayList;
import Enums.*;
import Main.*;

public class ScienceClass extends ScheduleDecorator{
	Schedule schedule;
	Classes thisClass = Classes.Science;
	
	public ScienceClass(Schedule schedule) {
		this.schedule = schedule;
	}
	
	public String getDescription() {
		return schedule.getDescription();
	}
	
	public ArrayList<Classes> Classes() {
		schedule.Classes().add(thisClass);
		return schedule.Classes();
	}
	
	public ArrayList<Activities> Activities() {
		return schedule.Activities();
	}

	public ArrayList<Jobs> Jobs() {
		return schedule.Jobs();
	}
}
