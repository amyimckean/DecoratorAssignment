package Decorators;

import java.util.ArrayList;
import Main.*;

public class MovingVehicleActivity extends ScheduleDecorator {
	Schedule schedule;
	String activity = "Cars, Helicopters, Trains";
	
	public MovingVehicleActivity(Schedule schedule) {
		this.schedule = schedule;
	}
	
	public String Activities() {
		schedule.activities += ", " + activity;
		return schedule.Activities();
	}

	public String Classes() {
		return schedule.Classes();
	}

	public String Jobs() {
		return schedule.Jobs();
	}
}