package Decorators;

import java.util.ArrayList;
import Enums.*;
import Main.*;

public class TeethingActivity extends ScheduleDecorator {
	Schedule schedule;
	String activity = "Teething";
	
	public TeethingActivity(Schedule schedule) {
		this.schedule = schedule;
	}
	
	public ArrayList<Activities> Activities() {
		schedule.Activities().add(activity);
		return schedule.Activities();
	}

	public String getDescription() {
		return schedule.getDescription();
	}

	public ArrayList<Jobs> Jobs() {
		return schedule.Jobs();
	}

	public ArrayList<Classes> Classes() {
		return schedule.Classes();
	}
}
