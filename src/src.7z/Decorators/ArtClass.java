package Decorators;

import Main.*;

public class ArtClass extends ScheduleDecorator{
	Schedule schedule;
	String thisClass = "Art";
	
	public ArtClass(Schedule schedule) {
		this.schedule = schedule;
	}
	
	public String getDescription() {
		return schedule.getDescription();
	}
	
	public String Classes() {
		schedule.classes += ", " + thisClass;
		return schedule.Classes();
	}
	
	public String Activities() {
		return schedule.Activities();
	}

	public String Jobs() {
		return schedule.Jobs();
	}
}
