package Decorators;

import java.util.ArrayList;
import Enums.*;
import Main.*;

public class MathClass extends ScheduleDecorator{
	Schedule schedule;
	Classes thisClass = Classes.Math;
	
	public MathClass(Schedule schedule) {
		this.schedule = schedule;
	}
	
	public String getDescription() {
		return schedule.getDescription();
	}
	
	public ArrayList<Classes> Classes() {
		schedule.Classes().add(thisClass);
		return schedule.Classes();
	}
	
	public ArrayList<Activities> Activities() {
		return schedule.Activities();
	}

	public ArrayList<Jobs> Jobs() {
		return schedule.Jobs();
	}
}
