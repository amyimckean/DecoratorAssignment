package Decorators;

import java.util.ArrayList;
import Enums.*;
import Main.*;

public class SoftwareEngineerJob extends ScheduleDecorator {
	Schedule schedule;
	Jobs job = Jobs.SoftwareEngineer;
	
	public SoftwareEngineerJob(Schedule schedule) {
		this.schedule = schedule;
	}
	
	public String getDescription() {
		return schedule.getDescription();
	}
	
	public ArrayList<Jobs> Jobs() {
		schedule.Jobs().add(job);
		return schedule.Jobs();
	}
	
	public ArrayList<Classes> Classes() {
		return schedule.Classes();
	}
	
	public ArrayList<Activities> Activities() {
		return schedule.Activities();
	}
}
