package Decorators;

import java.util.ArrayList;
import Enums.*;
import Main.*;

public class BaseballActivity extends ScheduleDecorator {
	Schedule schedule;
	Activities activity = Activities.Baseball;
	
	public BaseballActivity(Schedule schedule) {
		this.schedule = schedule;
	}
	
	public ArrayList<Activities> Activities() {
		schedule.Activities().add(activity);
		return schedule.Activities();
	}

	public String getDescription() {
		return schedule.getDescription();
	}

	public ArrayList<Jobs> Jobs() {
		return schedule.Jobs();
	}

	public ArrayList<Classes> Classes() {
		return schedule.Classes();
	}
}
