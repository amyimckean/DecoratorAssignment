package Main;

public abstract class ScheduleDecorator extends Schedule {
	public abstract String Classes();
	public abstract String Jobs();
	public abstract String Activities();
}
