package Main;

public abstract class Schedule {
	public String description;
	public String classes = "Classes: None";
	public String jobs = "Jobs: None";
	public String activities = "Activities: None";
	
	public String getDescription() {
		return description;
	}
	
	public String Jobs(){
		return jobs;
	}

	public String Classes(){
		return classes;
	}
	
	public String Activities(){
		return activities;
	}
}
