package Schedules;

import Main.*;

public class ChrisSchedule extends Schedule  {

	public ChrisSchedule() {
		description = "Chris' Schedule";
	}
}
