package Schedules;

import Main.*;

public class CrewSchedule extends Schedule  {

	public CrewSchedule() {
		description = "Crew's Schedule";
	}
}
