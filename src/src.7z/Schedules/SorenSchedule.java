package Schedules;
import Main.*;

public class SorenSchedule extends Schedule  {

	public SorenSchedule() {
		description = "Soren's Schedule";
	}
}
