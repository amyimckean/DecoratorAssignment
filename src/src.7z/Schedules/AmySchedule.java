package Schedules;

import Main.*;

public class AmySchedule extends Schedule  {

	public AmySchedule() {
		description = "Amy's Schedule";
	}
}

